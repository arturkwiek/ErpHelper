# opencv-cascade-tester
Project for testing OpenCV casscades classifiers
