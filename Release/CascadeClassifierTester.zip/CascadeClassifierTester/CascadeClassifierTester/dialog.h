#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private slots:
    void on_btnOpenCascadeFile_clicked();

    void on_chbDetect_clicked(bool checked);

    void on_leScaleFactor_textChanged(const QString &arg1);

    void on_leMinNeighbours_textChanged(const QString &arg1);

    void on_leMaxSize_textChanged(const QString &arg1);

    void on_leMinSize_textChanged(const QString &arg1);

    void on_chbGray_clicked();

    void on_slScaleFactor_valueChanged(int position);

    void on_slMinNeighbours_valueChanged(int position);

    void on_slMaxSize_valueChanged(int position);

    void on_slMinSize_valueChanged(int position);

    void on_chbMove_clicked(bool checked);

    void on_chbResize_clicked(bool checked);

    void on_slThickness_valueChanged(int position);

    void on_chbAngle_clicked(bool checked);

    void on_chbCorrectionAngle_clicked(bool checked);

    void on_chbFrameCross_clicked(bool checked);

    void on_chbObjectCross_clicked(bool checked);

    void on_chbLines_clicked(bool checked);

    void on_slFrameHorizontalCorrection_valueChanged(int value);

    void on_slFrameVerticalCorrection_valueChanged(int value);

    void on_slFaceHorizontalCorrection_valueChanged(int value);

    void on_slFaceVerticalCorrection_valueChanged(int value);

    void on_chbFlip_clicked(bool checked);

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
