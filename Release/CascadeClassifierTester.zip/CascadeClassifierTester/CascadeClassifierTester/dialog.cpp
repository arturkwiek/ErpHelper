#include "dialog.h"
#include "ui_dialog.h"
#include <QString>
#include <QtDebug>
#include <QFileDialog>

#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/videostab.hpp>

#define tap(x) qDebug() << x << endl
using namespace cv;

Mat frame;
CascadeClassifier cascade_classifier;
QString cascade_classifier_file;

bool b_gray = false;
bool b_window = true;
bool b_opened = false;
bool b_loaded_file = false;
bool b_detect = false;
bool b_move = true;
bool b_resize = true;
bool b_angle = false;
bool b_frame_cross = false;
bool b_object_cross = false;
bool b_lines = false;
bool b_flip = true;

double fScaleFactor = 1.1;
int iMinNeighbors = 3;
int iFlags = 2;
long lMaxSize = 30;
long lMinSize = 30;
int iThickness = 3;
int iFrameVerticalCorrection = 0;
int iFrameHorizontalCorrection = 0;
int iFaceVerticalCorrection = 0;
int iFaceHorizontalCorrection = 0;
double fVerticalAngle = 0.0;
double fCorrectionAngle = 0.0;


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    QDoubleValidator * fValidator = new QDoubleValidator(this);
    ui->leScaleFactor->setValidator(fValidator);
    QIntValidator * iValidator = new QIntValidator(this);
    ui->leMinNeighbours->setValidator(iValidator);
    ui->leMaxSize->setValidator(iValidator);
    ui->leMinSize->setValidator(iValidator);
}

Dialog::~Dialog()
{
    tap("~Dialog()");
    delete ui;
}


void Dialog::on_btnOpenCascadeFile_clicked()
{
    cascade_classifier_file = QFileDialog::getOpenFileName(this,
                                                           tr("Open Image"), ".", tr("Cascade Classifier Files (*.xml)"));
    b_loaded_file = true;

    //    QStringList pieces = url.split( "/" );
    //    QString neededWord = pieces.value( pieces.length() - 2 );

    QStringList path_steps = cascade_classifier_file.split( "/" );
    ui->lblCascadeFile->setText(path_steps.value(path_steps.length() - 1));
    tap(cascade_classifier_file);

}

void Dialog::on_chbDetect_clicked(bool checked)
{
    b_detect = ui->chbDetect->isChecked();
}

void Dialog::on_leScaleFactor_textChanged(const QString &arg1)
{
    ui->leScaleFactor->setText(ui->leScaleFactor->text().replace(",","."));
    if((!ui->leScaleFactor->text().isEmpty()) &&(ui->leScaleFactor->text().toDouble() >1)) {
        fScaleFactor = ui->leScaleFactor->text().toDouble();
        tap( "fScaleFactor: " << fScaleFactor);
    } else  {
        ui->leScaleFactor->setText("1.1");//fScaleFactor = 1.1;
        tap( "Must change fScaleFactor(can't be 0): " << fScaleFactor);
    }
    ui->slScaleFactor->setValue(fScaleFactor*10);
}

void Dialog::on_leMinNeighbours_textChanged(const QString &arg1)
{
    iMinNeighbors = ui->leMinNeighbours->text().toInt();
    tap("iMinNeighbors: " << iMinNeighbors);
    if(iMinNeighbors<11)
        ui->slMinNeighbours->setValue(iMinNeighbors);
    else
        ui->slMinNeighbours->setValue(10);
}

void Dialog::on_leMaxSize_textChanged(const QString &arg1)
{
    lMaxSize = ui->leMaxSize->text().toLong();
    tap("lMaxSize: " << lMaxSize);
    ui->slMaxSize->setValue(lMaxSize);
}

void Dialog::on_leMinSize_textChanged(const QString &arg1)
{
    lMinSize = ui->leMinSize->text().toLong();
    tap("lMinSize: " << lMinSize);
    ui->slMinSize->setValue(lMinSize);
}

void Dialog::on_chbGray_clicked()
{
    b_gray = ui->chbGray->isChecked();
    tap("bgray " << b_gray);
}

void Dialog::on_slScaleFactor_valueChanged(int value)
{
    tap( "value: " << value);
    fScaleFactor = value/10.0;
    tap( "fScaleFactor: " << fScaleFactor);
    ui->leScaleFactor->setText(QString::number(fScaleFactor));
    tap( "leScaleFactor: " << ui->leScaleFactor->text());

}

void Dialog::on_slMinNeighbours_valueChanged(int value)
{
    tap( "value: " << value);
    iMinNeighbors = value;//ui->lsMinNeighbours->value();
    ui->leMinNeighbours->setText(QString::number(iMinNeighbors));
    tap( "leMinNeighbours: " << ui->leMinNeighbours->text());

}

void Dialog::on_slMaxSize_valueChanged(int value)
{
    tap( "value: " << value);
    lMaxSize = value;
    tap( "lMaxSize: " << lMaxSize);
    ui->leMaxSize->setText(QString::number(lMaxSize));
    tap( "leMaxSize: " << ui->leMaxSize->text());

}

void Dialog::on_slMinSize_valueChanged(int value)
{
    tap( "value: " << value);
    lMinSize = value;
    tap( "lMinSize: " << lMinSize);
    ui->leMinSize->setText(QString::number(lMinSize));
    tap( "leMinSize: " << ui->leMinSize->text());
}

void Dialog::on_chbMove_clicked(bool checked)
{
    b_move = checked;
}

void Dialog::on_chbResize_clicked(bool checked)
{
    b_resize = checked;
}

void Dialog::on_slThickness_valueChanged(int value)
{
    tap( "value: " << value);
    iThickness = value;
    tap( "iThickness: " << iThickness);
    ui->lblThickness->setText(QString::number(iThickness));
//    ui->leMinSize->setText(QString::number(lMinSize));
//    tap( "leMinSize: " << ui->leMinSize->text());
}

void Dialog::on_chbAngle_clicked(bool checked)
{
    b_angle = checked;
    tap( "b_angle: " << b_angle);
}

void Dialog::on_chbCorrectionAngle_clicked(bool checked)
{
    if(checked)
        fCorrectionAngle = fVerticalAngle;
    else
        fCorrectionAngle = 0.0;
    ui->chbCorrectionAngle->setText(QString::number(180*fCorrectionAngle/M_PI,'f',2));
}

void Dialog::on_chbFrameCross_clicked(bool checked)
{
    b_frame_cross = checked;
}

void Dialog::on_chbObjectCross_clicked(bool checked)
{
    b_object_cross = checked;
}

void Dialog::on_chbLines_clicked(bool checked)
{
    b_lines = checked;
}

void Dialog::on_slFrameVerticalCorrection_valueChanged(int value)
{
    tap( "value: " << value);
    iFrameVerticalCorrection = value;
    tap( "iFrameVerticalCorrection: " << iFrameVerticalCorrection);
    ui->lblFrameVerticalCorrection->setText(QString::number(value));

}

void Dialog::on_slFrameHorizontalCorrection_valueChanged(int value)
{
    tap( "value: " << value);
    iFrameHorizontalCorrection = value;
    tap( "iFrameHorizontalCorrection: " << iFrameHorizontalCorrection);
    ui->lblFrameHorizontalCorection->setText(QString::number(value));

}

void Dialog::on_slFaceVerticalCorrection_valueChanged(int value)
{
    tap( "value: " << value);
    iFaceVerticalCorrection = value;
    tap( "iFaceVerticalCorrection: " << iFaceVerticalCorrection);
    ui->lblFaceVerticalCorrection->setText(QString::number(value));

}

void Dialog::on_slFaceHorizontalCorrection_valueChanged(int value)
{
    tap( "value: " << value);
    iFaceHorizontalCorrection = value;
    tap( "iFaceHorizontalCorrection: " << iFaceHorizontalCorrection);
    ui->lblFaceHorizontalCorection->setText(QString::number(value));

}

void Dialog::on_chbFlip_clicked(bool checked)
{
    b_flip = checked;
}
