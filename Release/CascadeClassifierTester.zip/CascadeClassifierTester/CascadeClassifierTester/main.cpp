#include "dialog.h"
#include <QApplication>
#include <QString>
#include <QDebug>
#include <QVector>
#include <windows.h>

#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/videostab.hpp>

#define tap(x) qDebug() << x << endl

using namespace cv;
using namespace std;

extern Mat frame;
extern CascadeClassifier cascade_classifier;
extern QString cascade_classifier_file;
extern bool b_gray;
extern bool b_window;
extern bool b_opened;
extern bool b_loaded_file;
extern bool b_detect;
extern bool b_move;
extern bool b_resize;
extern bool b_angle;
extern bool b_frame_cross;
extern bool b_object_cross;
extern bool b_lines;
extern bool b_flip;

extern double fScaleFactor;
extern int iMinNeighbors;
extern int iFlags;
extern long lMaxSize;
extern long lMinSize;
extern int iThickness;
extern int iFrameVerticalCorrection;
extern int iFrameHorizontalCorrection;
extern int iFaceVerticalCorrection;
extern int iFaceHorizontalCorrection;
extern double fVerticalAngle;
extern double fCorrectionAngle;


void drawFrameCross(uint8_t red, uint8_t green, uint8_t blue);
void drawFaceCross(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue);
void drawObjectCross(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue);
void drawFaces(vector <Rect> faces, uint8_t red, uint8_t green, uint8_t blue);
void drawObjects(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue);
void drawLines(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue);

int main(int argc, char *argv[])
{
    tap("1");
    QApplication a(argc, argv);
    Dialog w;
    w.show();

    CascadeClassifier face_classifier;
    CascadeClassifier eyes_classifier;
    CascadeClassifier cascade_classifier;

    tap("hey!");
    QString face_classifier_file = "cascades/haarcascade_frontalface_alt.xml";
    QString eyes_classifier_file = "haarcascade_eye_tree_eyeglasses.xml";

    int key;
    VideoCapture capture(0);

    if(!face_classifier.load(face_classifier_file.toStdString())) {
        qDebug() << "1. Couldn't load face_classifier_file: " << endl;
        return -1;
    }

    //    if(!cascade_classifier_file.isEmpty())
    //        cascade_classifier.load(cascade_classifier_file.toStdString());
    //    ////    if(!eyes_classifier.load("cascades/" + haarcascade_eye_tree_eyeglasses.toStdString())) {
    //    ////        qDebug() << "Couldn't load classifier: " << haarcascade_eye_tree_eyeglasses << endl;
    //    ////        return -1;
    //    ////    }

    vector <Rect> faces;
    vector <Rect> objects;
    for(;;) {

        if(b_loaded_file && !cascade_classifier_file.isEmpty()) {
            if(!cascade_classifier.load(cascade_classifier_file.toStdString())) {
                qDebug() << "Couldn't load cascade_classifier_file: " <<  endl;
                return -1;
            } else {
                b_loaded_file = false;
            }
        }

        capture >> frame; /*capture video frame */

        if(true == b_flip)
            flip(frame,frame,1);

        if(true == b_detect) { /* detect objects */
            if(!face_classifier.empty())
                face_classifier.detectMultiScale(frame,faces,1.1,3,2,Size(100,100));

            (fScaleFactor==0?1:fScaleFactor);
            if(!cascade_classifier.empty())
                cascade_classifier.detectMultiScale(frame,objects,fScaleFactor, iMinNeighbors, iFlags, Size(lMaxSize, lMinSize));

            drawObjects(faces, 0, 0, 255);

            if(true == b_object_cross)
                drawFaceCross(faces,0,0,255);
            if(true == b_lines)
                drawLines(faces,0,0,255);
//            if(!faces.empty())
//                for(size_t i =0;i< faces.size();i++)
//                    rectangle(frame,faces[i].tl(),faces[i].br(),Scalar(0,0,255),iThickness);

//            draw_objects(objects, 0, 255, 255);
            if(!objects.empty()){
                drawObjects(objects, 0, 255, 255);
                if(true == b_object_cross)
                    drawObjectCross(objects,0,255,255);
                if(true == b_lines)
                    drawLines(objects,0,255,255);
//                for(size_t i =0;i< objects.size();i++)
//                    rectangle(frame,objects[i].tl(),objects[i].br(),Scalar(0,255,255),iThickness);
                if(objects.size() == 2) {
                    Point p1,p2;
                    double angle;
                    double dx, dy;
                    QString strAngle, strCorrectionAngle;

                    p1.x = objects[0].x +objects[0].width/2;
                    p1.y = objects[0].y +objects[0].height/2;
                    p2.x = objects[1].x +objects[1].width/2;
                    p2.y = objects[1].y +objects[1].height/2;

                    if(b_angle) {
                        dx = p2.x-p1.x;
                        dy = p2.y-p1.y;
                        tap("dx" << dx);
                        tap("dy" << dy);
                        if(dx!=0) {
                            fVerticalAngle = atan((dy)/(dx));
                            tap("angle" << 180*fVerticalAngle/M_PI);
                        }
                    }
                    line(frame, p1, p2, Scalar( 110, 220, 0 ),  iThickness/2, 8 );
                    strAngle = QString::number(180*fVerticalAngle/M_PI);
                    strCorrectionAngle = QString::number(180*(fVerticalAngle-fCorrectionAngle)/M_PI,'f',2);

                    if(fCorrectionAngle == 0.0)
                        putText(frame,strAngle.toStdString(),Point(frame.cols/5,frame.rows/5), FONT_HERSHEY_SIMPLEX, 2,Scalar(255,255,255),3,LINE_AA);
                    else
                        putText(frame,strCorrectionAngle.toStdString(),Point(frame.cols/5,frame.rows/5), FONT_HERSHEY_SIMPLEX, 2,Scalar(255,255,255),3,LINE_AA);
                }
            }
        }

        if(true == b_gray)
            cvtColor(frame, frame, CV_BGR2GRAY);
#define _RESIZE4_
        //#define _RESIZE2_
#ifdef _RESIZE4_
        if(b_resize) {
            resize(frame,frame, Size(frame.cols/4,frame.rows/4));
        }
#endif
        if(b_frame_cross)
            drawFrameCross(255,255,255);

        namedWindow("OpencvVideoTemplate", CV_WINDOW_AUTOSIZE | CV_WINDOW_KEEPRATIO | CV_GUI_NORMAL );

#define _MOVE_WINDOW_
#ifdef _MOVE_WINDOW_
        if(b_move) {
            RECT DesktopRect;
            // Gets the Desktop window
            HWND hDesktop=GetDesktopWindow();
            // Gets the Desktop window rect or screen resolution in pixels
            GetWindowRect(hDesktop, &DesktopRect);
            //        tap( DesktopRect.bottom << " x " << DesktopRect.top <<  " x " << DesktopRect.left <<  " x " << DesktopRect.right);
            moveWindow("OpencvVideoTemplate", DesktopRect.right - frame.cols - 20, DesktopRect.bottom - frame.rows - 80);
        }
#endif

        imshow("OpencvVideoTemplate", frame);

        key = waitKey(30);
        if('w' == key)
            w.show();
        if('q' == key)
            return 0;

    }
    return a.exec();
}

//void draw_faces(vector <Rect> faces, uint8_t red, uint8_t green, uint8_t blue) {

//if(!faces.empty())
//    for(size_t i =0;i< faces.size();i++)
//        rectangle(frame,faces[i].tl(),faces[i].br(),Scalar(red,green,blue),iThickness);
//}

void drawObjects(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue) {
if(!objects.empty())
    for(size_t i =0;i< objects.size();i++)
        rectangle(frame,objects[i].tl(),objects[i].br(),Scalar(red,green,blue),iThickness);

}

void drawFrameCross(uint8_t red, uint8_t green, uint8_t blue) {

    Point   center_up,
            center_down,
            center_left,
            center_right;

    center_up.x = frame.cols/2 + iFrameHorizontalCorrection*frame.cols/100;
    center_up.y = 0;
    center_down.x = frame.cols/2 + iFrameHorizontalCorrection*frame.cols/100;
    center_down.y = frame.rows;
    center_left.x = 0;
    center_left.y = frame.rows/2 + iFrameVerticalCorrection*frame.rows/100;
    center_right.x = frame.cols;
    center_right.y = frame.rows/2 + iFrameVerticalCorrection*frame.rows/100;

    line(frame,center_up,center_down,Scalar(red,green,blue),iThickness/4);
    line(frame,center_left,center_right,Scalar(red,green,blue),iThickness/4);
}

void drawFaceCross(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue) {

    Point   center_up,
            center_down,
            center_left,
            center_right;


    if(!objects.empty())
        for(size_t i =0;i< objects.size();i++) {

            center_up.x = objects[i].x + objects[i].width/2 + iFaceHorizontalCorrection*objects[i].width/100;
            center_up.y = objects[i].y;
            center_down.x = objects[i].x + objects[i].width/2 + iFaceHorizontalCorrection*objects[i].width/100;
            center_down.y = objects[i].y + objects[i].height;
            center_left.x = objects[i].x;
            center_left.y = objects[i].y + objects[i].height/2 + iFaceVerticalCorrection*objects[i].height/100;
            center_right.x = objects[i].x + objects[i].width;
            center_right.y = objects[i].y + objects[i].height/2 + iFaceVerticalCorrection*objects[i].height/100;

            line(frame,center_up,center_down,Scalar(red,green,blue),iThickness/2);
            line(frame,center_left,center_right,Scalar(red,green,blue),iThickness/2);

        }

}

void drawObjectCross(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue) {

    Point   center_up,
            center_down,
            center_left,
            center_right;


    if(!objects.empty())
        for(size_t i =0;i< objects.size();i++) {

            center_up.x = objects[i].x + objects[i].width/2;
            center_up.y = objects[i].y;
            center_down.x = objects[i].x + objects[i].width/2;;
            center_down.y = objects[i].y + objects[i].height;
            center_left.x = objects[i].x;
            center_left.y = objects[i].y + objects[i].height/2;
            center_right.x = objects[i].x + objects[i].width;
            center_right.y = objects[i].y + objects[i].height/2;

            line(frame,center_up,center_down,Scalar(red,green,blue),iThickness/2);
            line(frame,center_left,center_right,Scalar(red,green,blue),iThickness/2);

        }

}

void drawLines(vector <Rect> objects, uint8_t red, uint8_t green, uint8_t blue) {

    Point   center_up,
            center_down;


    if(!objects.empty())
        for(size_t i =0;i< objects.size();i++) {

            center_up.x = objects[i].x + objects[i].width/2;
            center_up.y = 0;
            center_down.x = objects[i].x + objects[i].width/2;;
            center_down.y = frame.rows;
//            center_left.x = objects[i].x;
//            center_left.y = objects[i].y + objects[i].height/2;
//            center_right.x = objects[i].x + objects[i].width;
//            center_right.y = objects[i].y + objects[i].height/2;

            line(frame,center_up,center_down,Scalar(red,green,blue),iThickness/2);
//            line(frame,center_left,center_right,Scalar(red,green,blue),iThickness/2);

        }

}
