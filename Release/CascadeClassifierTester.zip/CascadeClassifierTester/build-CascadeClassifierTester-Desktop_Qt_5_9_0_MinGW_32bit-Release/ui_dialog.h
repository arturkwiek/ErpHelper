/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QGroupBox *groupBox;
    QCheckBox *chbLines;
    QCheckBox *chbCorrection;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout_8;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_11;
    QLabel *label_12;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_7;
    QLabel *label_9;
    QVBoxLayout *verticalLayout_4;
    QSlider *slFrameVerticalCorrection;
    QSlider *slFaceVerticalCorrection;
    QVBoxLayout *verticalLayout_5;
    QLabel *lblFrameVerticalCorrection;
    QLabel *lblFaceVerticalCorrection;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_8;
    QLabel *label_10;
    QVBoxLayout *verticalLayout_7;
    QSlider *slFrameHorizontalCorrection;
    QSlider *slFaceHorizontalCorrection;
    QVBoxLayout *verticalLayout_8;
    QLabel *lblFrameHorizontalCorection;
    QLabel *lblFaceHorizontalCorection;
    QGroupBox *groupBox_2;
    QPushButton *btnOpenCascadeFile;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_6;
    QLabel *lblCascadeFile;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QLineEdit *leScaleFactor;
    QSlider *slScaleFactor;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLineEdit *leMinNeighbours;
    QSlider *slMinNeighbours;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label;
    QComboBox *cbFlags;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_2;
    QLineEdit *leMaxSize;
    QSlider *slMaxSize;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_5;
    QLineEdit *leMinSize;
    QSlider *slMinSize;
    QCheckBox *chbDetect;
    QGroupBox *groupBox_3;
    QCheckBox *chbResize;
    QCheckBox *chbGray;
    QCheckBox *chbFlip;
    QCheckBox *chbMove;
    QCheckBox *chbAngle;
    QCheckBox *chbCorrectionAngle;
    QGroupBox *groupBox_4;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_6;
    QSlider *slThickness;
    QLabel *lblThickness;
    QCheckBox *chbObjectCross;
    QCheckBox *chbFrameCross;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(481, 558);
        groupBox = new QGroupBox(Dialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 110, 461, 130));
        chbLines = new QCheckBox(groupBox);
        chbLines->setObjectName(QStringLiteral("chbLines"));
        chbLines->setGeometry(QRect(30, 100, 50, 20));
        chbLines->setMaximumSize(QSize(112, 16777215));
        QFont font;
        font.setPointSize(10);
        chbLines->setFont(font);
        chbLines->setChecked(false);
        chbCorrection = new QCheckBox(groupBox);
        chbCorrection->setObjectName(QStringLiteral("chbCorrection"));
        chbCorrection->setGeometry(QRect(100, 100, 80, 20));
        chbCorrection->setFont(font);
        horizontalLayoutWidget = new QWidget(groupBox);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 20, 441, 70));
        horizontalLayout_8 = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_11 = new QLabel(horizontalLayoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setFont(font);

        verticalLayout_2->addWidget(label_11);

        label_12 = new QLabel(horizontalLayoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setFont(font);

        verticalLayout_2->addWidget(label_12);


        horizontalLayout_8->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_7 = new QLabel(horizontalLayoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font);

        verticalLayout_3->addWidget(label_7);

        label_9 = new QLabel(horizontalLayoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setFont(font);

        verticalLayout_3->addWidget(label_9);


        horizontalLayout_8->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        slFrameVerticalCorrection = new QSlider(horizontalLayoutWidget);
        slFrameVerticalCorrection->setObjectName(QStringLiteral("slFrameVerticalCorrection"));
        slFrameVerticalCorrection->setMinimumSize(QSize(100, 0));
        slFrameVerticalCorrection->setMaximumSize(QSize(150, 16777215));
        slFrameVerticalCorrection->setMinimum(-50);
        slFrameVerticalCorrection->setMaximum(50);
        slFrameVerticalCorrection->setValue(0);
        slFrameVerticalCorrection->setOrientation(Qt::Horizontal);
        slFrameVerticalCorrection->setTickPosition(QSlider::NoTicks);
        slFrameVerticalCorrection->setTickInterval(1);

        verticalLayout_4->addWidget(slFrameVerticalCorrection);

        slFaceVerticalCorrection = new QSlider(horizontalLayoutWidget);
        slFaceVerticalCorrection->setObjectName(QStringLiteral("slFaceVerticalCorrection"));
        slFaceVerticalCorrection->setMinimumSize(QSize(100, 0));
        slFaceVerticalCorrection->setMaximumSize(QSize(150, 16777215));
        slFaceVerticalCorrection->setMinimum(-50);
        slFaceVerticalCorrection->setMaximum(50);
        slFaceVerticalCorrection->setValue(0);
        slFaceVerticalCorrection->setOrientation(Qt::Horizontal);
        slFaceVerticalCorrection->setTickPosition(QSlider::NoTicks);
        slFaceVerticalCorrection->setTickInterval(1);

        verticalLayout_4->addWidget(slFaceVerticalCorrection);


        horizontalLayout_8->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        lblFrameVerticalCorrection = new QLabel(horizontalLayoutWidget);
        lblFrameVerticalCorrection->setObjectName(QStringLiteral("lblFrameVerticalCorrection"));
        lblFrameVerticalCorrection->setFont(font);

        verticalLayout_5->addWidget(lblFrameVerticalCorrection);

        lblFaceVerticalCorrection = new QLabel(horizontalLayoutWidget);
        lblFaceVerticalCorrection->setObjectName(QStringLiteral("lblFaceVerticalCorrection"));
        lblFaceVerticalCorrection->setFont(font);

        verticalLayout_5->addWidget(lblFaceVerticalCorrection);


        horizontalLayout_8->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label_8 = new QLabel(horizontalLayoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font);

        verticalLayout_6->addWidget(label_8);

        label_10 = new QLabel(horizontalLayoutWidget);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setFont(font);

        verticalLayout_6->addWidget(label_10);


        horizontalLayout_8->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        slFrameHorizontalCorrection = new QSlider(horizontalLayoutWidget);
        slFrameHorizontalCorrection->setObjectName(QStringLiteral("slFrameHorizontalCorrection"));
        slFrameHorizontalCorrection->setMinimumSize(QSize(100, 0));
        slFrameHorizontalCorrection->setMaximumSize(QSize(150, 16777215));
        slFrameHorizontalCorrection->setMinimum(-50);
        slFrameHorizontalCorrection->setMaximum(50);
        slFrameHorizontalCorrection->setValue(0);
        slFrameHorizontalCorrection->setOrientation(Qt::Horizontal);
        slFrameHorizontalCorrection->setTickPosition(QSlider::NoTicks);
        slFrameHorizontalCorrection->setTickInterval(1);

        verticalLayout_7->addWidget(slFrameHorizontalCorrection);

        slFaceHorizontalCorrection = new QSlider(horizontalLayoutWidget);
        slFaceHorizontalCorrection->setObjectName(QStringLiteral("slFaceHorizontalCorrection"));
        slFaceHorizontalCorrection->setMinimumSize(QSize(100, 0));
        slFaceHorizontalCorrection->setMaximumSize(QSize(150, 16777215));
        slFaceHorizontalCorrection->setMinimum(-50);
        slFaceHorizontalCorrection->setMaximum(50);
        slFaceHorizontalCorrection->setValue(0);
        slFaceHorizontalCorrection->setOrientation(Qt::Horizontal);
        slFaceHorizontalCorrection->setTickPosition(QSlider::NoTicks);
        slFaceHorizontalCorrection->setTickInterval(1);

        verticalLayout_7->addWidget(slFaceHorizontalCorrection);


        horizontalLayout_8->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        lblFrameHorizontalCorection = new QLabel(horizontalLayoutWidget);
        lblFrameHorizontalCorection->setObjectName(QStringLiteral("lblFrameHorizontalCorection"));
        lblFrameHorizontalCorection->setFont(font);

        verticalLayout_8->addWidget(lblFrameHorizontalCorection);

        lblFaceHorizontalCorection = new QLabel(horizontalLayoutWidget);
        lblFaceHorizontalCorection->setObjectName(QStringLiteral("lblFaceHorizontalCorection"));
        lblFaceHorizontalCorection->setFont(font);

        verticalLayout_8->addWidget(lblFaceHorizontalCorection);


        horizontalLayout_8->addLayout(verticalLayout_8);

        groupBox_2 = new QGroupBox(Dialog);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 250, 460, 291));
        btnOpenCascadeFile = new QPushButton(groupBox_2);
        btnOpenCascadeFile->setObjectName(QStringLiteral("btnOpenCascadeFile"));
        btnOpenCascadeFile->setGeometry(QRect(10, 20, 170, 30));
        btnOpenCascadeFile->setMinimumSize(QSize(170, 0));
        btnOpenCascadeFile->setMaximumSize(QSize(170, 16777215));
        btnOpenCascadeFile->setFont(font);
        layoutWidget = new QWidget(groupBox_2);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 60, 440, 31));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        lblCascadeFile = new QLabel(layoutWidget);
        lblCascadeFile->setObjectName(QStringLiteral("lblCascadeFile"));
        lblCascadeFile->setMaximumSize(QSize(438, 16777215));
        lblCascadeFile->setFont(font);
        lblCascadeFile->setFrameShape(QFrame::Box);
        lblCascadeFile->setFrameShadow(QFrame::Plain);

        horizontalLayout_6->addWidget(lblCascadeFile);

        layoutWidget1 = new QWidget(groupBox_2);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 100, 440, 175));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setMinimumSize(QSize(130, 0));
        label_4->setMaximumSize(QSize(130, 16777215));
        label_4->setFont(font);

        horizontalLayout_2->addWidget(label_4);

        leScaleFactor = new QLineEdit(layoutWidget1);
        leScaleFactor->setObjectName(QStringLiteral("leScaleFactor"));
        leScaleFactor->setMaximumSize(QSize(50, 16777215));
        QFont font1;
        font1.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font1.setPointSize(10);
        leScaleFactor->setFont(font1);
        leScaleFactor->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(leScaleFactor);

        slScaleFactor = new QSlider(layoutWidget1);
        slScaleFactor->setObjectName(QStringLiteral("slScaleFactor"));
        slScaleFactor->setMinimumSize(QSize(140, 0));
        slScaleFactor->setMaximumSize(QSize(16777215, 16777215));
        slScaleFactor->setMinimum(11);
        slScaleFactor->setMaximum(100);
        slScaleFactor->setOrientation(Qt::Horizontal);

        horizontalLayout_2->addWidget(slScaleFactor);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setMinimumSize(QSize(130, 0));
        label_3->setMaximumSize(QSize(130, 16777215));
        label_3->setFont(font);

        horizontalLayout->addWidget(label_3);

        leMinNeighbours = new QLineEdit(layoutWidget1);
        leMinNeighbours->setObjectName(QStringLiteral("leMinNeighbours"));
        leMinNeighbours->setMaximumSize(QSize(50, 16777215));
        leMinNeighbours->setFont(font1);
        leMinNeighbours->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(leMinNeighbours);

        slMinNeighbours = new QSlider(layoutWidget1);
        slMinNeighbours->setObjectName(QStringLiteral("slMinNeighbours"));
        slMinNeighbours->setMinimumSize(QSize(140, 0));
        slMinNeighbours->setMaximumSize(QSize(16777215, 16777215));
        slMinNeighbours->setMinimum(1);
        slMinNeighbours->setMaximum(10);
        slMinNeighbours->setValue(3);
        slMinNeighbours->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(slMinNeighbours);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        label = new QLabel(layoutWidget1);
        label->setObjectName(QStringLiteral("label"));
        label->setMinimumSize(QSize(130, 0));
        label->setMaximumSize(QSize(16777215, 16777215));
        label->setFont(font);

        horizontalLayout_3->addWidget(label);

        cbFlags = new QComboBox(layoutWidget1);
        cbFlags->setObjectName(QStringLiteral("cbFlags"));
        cbFlags->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_3->addWidget(cbFlags);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setMinimumSize(QSize(130, 0));
        label_2->setMaximumSize(QSize(130, 16777215));
        label_2->setFont(font);

        horizontalLayout_5->addWidget(label_2);

        leMaxSize = new QLineEdit(layoutWidget1);
        leMaxSize->setObjectName(QStringLiteral("leMaxSize"));
        leMaxSize->setMaximumSize(QSize(50, 16777215));
        leMaxSize->setFont(font1);
        leMaxSize->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_5->addWidget(leMaxSize);

        slMaxSize = new QSlider(layoutWidget1);
        slMaxSize->setObjectName(QStringLiteral("slMaxSize"));
        slMaxSize->setMinimumSize(QSize(140, 0));
        slMaxSize->setMaximumSize(QSize(16777215, 16777215));
        slMaxSize->setMinimum(1);
        slMaxSize->setMaximum(200);
        slMaxSize->setValue(30);
        slMaxSize->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(slMaxSize);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setMinimumSize(QSize(130, 0));
        label_5->setMaximumSize(QSize(130, 16777215));
        label_5->setFont(font);

        horizontalLayout_4->addWidget(label_5);

        leMinSize = new QLineEdit(layoutWidget1);
        leMinSize->setObjectName(QStringLiteral("leMinSize"));
        leMinSize->setMaximumSize(QSize(50, 16777215));
        leMinSize->setFont(font1);
        leMinSize->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_4->addWidget(leMinSize);

        slMinSize = new QSlider(layoutWidget1);
        slMinSize->setObjectName(QStringLiteral("slMinSize"));
        slMinSize->setMinimumSize(QSize(140, 0));
        slMinSize->setMaximumSize(QSize(16777215, 16777215));
        slMinSize->setMinimum(1);
        slMinSize->setMaximum(200);
        slMinSize->setValue(30);
        slMinSize->setOrientation(Qt::Horizontal);

        horizontalLayout_4->addWidget(slMinSize);


        verticalLayout->addLayout(horizontalLayout_4);

        chbDetect = new QCheckBox(groupBox_2);
        chbDetect->setObjectName(QStringLiteral("chbDetect"));
        chbDetect->setGeometry(QRect(200, 30, 147, 20));
        chbDetect->setMinimumSize(QSize(0, 0));
        chbDetect->setMaximumSize(QSize(147, 16777215));
        chbDetect->setFont(font);
        groupBox_3 = new QGroupBox(Dialog);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 10, 130, 90));
        chbResize = new QCheckBox(groupBox_3);
        chbResize->setObjectName(QStringLiteral("chbResize"));
        chbResize->setGeometry(QRect(10, 20, 70, 20));
        chbResize->setMaximumSize(QSize(112, 16777215));
        chbResize->setFont(font);
        chbResize->setChecked(true);
        chbGray = new QCheckBox(groupBox_3);
        chbGray->setObjectName(QStringLiteral("chbGray"));
        chbGray->setGeometry(QRect(10, 40, 60, 20));
        chbGray->setMaximumSize(QSize(112, 16777215));
        chbGray->setFont(font);
        chbFlip = new QCheckBox(groupBox_3);
        chbFlip->setObjectName(QStringLiteral("chbFlip"));
        chbFlip->setGeometry(QRect(10, 60, 60, 20));
        chbFlip->setMaximumSize(QSize(112, 16777215));
        chbFlip->setFont(font);
        chbFlip->setChecked(true);
        chbMove = new QCheckBox(groupBox_3);
        chbMove->setObjectName(QStringLiteral("chbMove"));
        chbMove->setGeometry(QRect(70, 20, 65, 20));
        chbMove->setMaximumSize(QSize(112, 16777215));
        chbMove->setFont(font);
        chbMove->setChecked(true);
        chbAngle = new QCheckBox(groupBox_3);
        chbAngle->setObjectName(QStringLiteral("chbAngle"));
        chbAngle->setGeometry(QRect(70, 40, 70, 20));
        chbAngle->setMaximumSize(QSize(112, 16777215));
        chbAngle->setFont(font);
        chbCorrectionAngle = new QCheckBox(groupBox_3);
        chbCorrectionAngle->setObjectName(QStringLiteral("chbCorrectionAngle"));
        chbCorrectionAngle->setGeometry(QRect(70, 60, 35, 20));
        chbCorrectionAngle->setFont(font);
        groupBox_4 = new QGroupBox(Dialog);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(160, 10, 310, 90));
        widget = new QWidget(groupBox_4);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 20, 290, 31));
        horizontalLayout_7 = new QHBoxLayout(widget);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font);

        horizontalLayout_7->addWidget(label_6);

        slThickness = new QSlider(widget);
        slThickness->setObjectName(QStringLiteral("slThickness"));
        slThickness->setMinimumSize(QSize(178, 0));
        slThickness->setMaximumSize(QSize(16777215, 16777215));
        slThickness->setMinimum(1);
        slThickness->setMaximum(10);
        slThickness->setValue(3);
        slThickness->setOrientation(Qt::Horizontal);
        slThickness->setTickPosition(QSlider::TicksBothSides);
        slThickness->setTickInterval(1);

        horizontalLayout_7->addWidget(slThickness);

        lblThickness = new QLabel(widget);
        lblThickness->setObjectName(QStringLiteral("lblThickness"));
        lblThickness->setFont(font);

        horizontalLayout_7->addWidget(lblThickness);

        chbObjectCross = new QCheckBox(groupBox_4);
        chbObjectCross->setObjectName(QStringLiteral("chbObjectCross"));
        chbObjectCross->setGeometry(QRect(110, 60, 90, 20));
        chbObjectCross->setMaximumSize(QSize(112, 16777215));
        chbObjectCross->setFont(font);
        chbObjectCross->setChecked(false);
        chbFrameCross = new QCheckBox(groupBox_4);
        chbFrameCross->setObjectName(QStringLiteral("chbFrameCross"));
        chbFrameCross->setGeometry(QRect(10, 60, 90, 20));
        chbFrameCross->setMaximumSize(QSize(112, 16777215));
        chbFrameCross->setFont(font);
        chbFrameCross->setChecked(false);
        QWidget::setTabOrder(btnOpenCascadeFile, chbMove);
        QWidget::setTabOrder(chbMove, chbResize);
        QWidget::setTabOrder(chbResize, chbGray);
        QWidget::setTabOrder(chbGray, chbDetect);
        QWidget::setTabOrder(chbDetect, chbAngle);
        QWidget::setTabOrder(chbAngle, chbCorrectionAngle);
        QWidget::setTabOrder(chbCorrectionAngle, chbFrameCross);
        QWidget::setTabOrder(chbFrameCross, chbObjectCross);
        QWidget::setTabOrder(chbObjectCross, chbLines);
        QWidget::setTabOrder(chbLines, chbCorrection);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Cascade Classifier Tester by A. Kwiek 2019.06.10", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("Dialog", "Osie", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbLines->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbLines->setText(QApplication::translate("Dialog", "lines", Q_NULLPTR));
        chbCorrection->setText(QApplication::translate("Dialog", "correction", Q_NULLPTR));
        label_11->setText(QApplication::translate("Dialog", "Frame", Q_NULLPTR));
        label_12->setText(QApplication::translate("Dialog", "Face", Q_NULLPTR));
        label_7->setText(QApplication::translate("Dialog", "Vertical", Q_NULLPTR));
        label_9->setText(QApplication::translate("Dialog", "Vertical", Q_NULLPTR));
        lblFrameVerticalCorrection->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        lblFaceVerticalCorrection->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        label_8->setText(QApplication::translate("Dialog", "Horizontal", Q_NULLPTR));
        label_10->setText(QApplication::translate("Dialog", "Horizontal", Q_NULLPTR));
        lblFrameHorizontalCorection->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        lblFaceHorizontalCorection->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("Dialog", "Kaskady HAAR", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        btnOpenCascadeFile->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Umo\305\274liwia wczytanie pliku kaskad do sprawdzenia</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        btnOpenCascadeFile->setText(QApplication::translate("Dialog", "Open Cascade Classifier ...", Q_NULLPTR));
        lblCascadeFile->setText(QApplication::translate("Dialog", "Cascade Classifier File", Q_NULLPTR));
        label_4->setText(QApplication::translate("Dialog", "double scaleFactor=1.1", Q_NULLPTR));
        leScaleFactor->setText(QApplication::translate("Dialog", "1.1", Q_NULLPTR));
        label_3->setText(QApplication::translate("Dialog", "int minNeighbors=3", Q_NULLPTR));
        leMinNeighbours->setText(QApplication::translate("Dialog", "3", Q_NULLPTR));
        label->setText(QApplication::translate("Dialog", "int flags=0", Q_NULLPTR));
        cbFlags->clear();
        cbFlags->insertItems(0, QStringList()
         << QApplication::translate("Dialog", "Flags", Q_NULLPTR)
         << QApplication::translate("Dialog", "(unknown)", Q_NULLPTR)
        );
        cbFlags->setCurrentText(QApplication::translate("Dialog", "Flags", Q_NULLPTR));
        label_2->setText(QApplication::translate("Dialog", "Size maxSize=Size()", Q_NULLPTR));
        leMaxSize->setText(QApplication::translate("Dialog", "30", Q_NULLPTR));
        label_5->setText(QApplication::translate("Dialog", "Size minSize=Size()", Q_NULLPTR));
        leMinSize->setText(QApplication::translate("Dialog", "30", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbDetect->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Uaktywnia detekcj\304\231 obiekt\303\263w wg kaskad (wykrywania twarzy i wczytanej)</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbDetect->setText(QApplication::translate("Dialog", "detectMultiscale", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("Dialog", "Source", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbResize->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbResize->setText(QApplication::translate("Dialog", "resize", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbGray->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbGray->setText(QApplication::translate("Dialog", "gray", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbFlip->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbFlip->setText(QApplication::translate("Dialog", "flip", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbMove->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbMove->setText(QApplication::translate("Dialog", "move", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbAngle->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbAngle->setText(QApplication::translate("Dialog", "angle", Q_NULLPTR));
        chbCorrectionAngle->setText(QApplication::translate("Dialog", "0", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("Dialog", "Frame window", Q_NULLPTR));
        label_6->setText(QApplication::translate("Dialog", "Thickness", Q_NULLPTR));
        lblThickness->setText(QApplication::translate("Dialog", "3", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbObjectCross->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbObjectCross->setText(QApplication::translate("Dialog", "object cross", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        chbFrameCross->setToolTip(QApplication::translate("Dialog", "<html><head/><body><p>Aktywuje konwersj\304\231 strumienia do skali szaro\305\233ci</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        chbFrameCross->setText(QApplication::translate("Dialog", "frame cross", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
